import { render, screen } from '@testing-library/react';
import Login from './login/Login';
import CreateAccount from './create/CreateAccount';


test('renders login component', () => {
  render(<Login setToken={()=>jest.fn()} />);
  const linkElement = screen.getByTestId('login');
  expect(linkElement).toBeInTheDocument();
});
test('renders create component', () => {
  render(<CreateAccount  />);
  const linkElement = screen.getByTestId('create');
  expect(linkElement).toBeInTheDocument();
});
