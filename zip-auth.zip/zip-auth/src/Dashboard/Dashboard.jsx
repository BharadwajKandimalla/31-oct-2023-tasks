import React from "react";
import { Link } from "react-router-dom/cjs/react-router-dom.min";
const Dashboard = () => {
  const logoutHandler = () => {
    localStorage.removeItem("Mytoken");
    window.location.reload();
  };
  return (
    <>
      <Link to="/createaccount">Create Account</Link>
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <Link to="/login">Login Account</Link>
      {/* <div className="card my_login_card">

        <div className="card-body">
          <h3>click here to Logout</h3>
        

          <button
            type="submit"
            className="btn btn-danger"
            onClick={logoutHandler}
          >
            Logout
          </button>
        </div>
      </div> */}
    </>
  );
};
export default Dashboard;
