import React, { useState } from "react";
import { Link } from "react-router-dom/cjs/react-router-dom.min";
const CreateAccount = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setRes] = useState("");
  const submitDetails = async (e) => {
    e.preventDefault();
    const token = await CreateUser({
      username: email,
      password: password,
    });
  };
  async function CreateUser(credentials) {
    return fetch("https://dummyjson.com/auth/create", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(credentials),
    })
      .then((res) => res.json())
      .then((resp) => {
        setRes(resp?.message);
        setTimeout(() => {
          setRes("");
        }, 5000);
        setEmail("");
        setPassword("");
      });
  }

  return (
    <div data-testid="create">
      <div class="card my_login_card">
        <div>
          <strong> Create Account Page: </strong>
          <Link to="/dashboard">Go To Dashbaord</Link>
        </div>
        <div class="card-body">
          <form>
            <div class="mb-3">
              <label for="exampleInputEmail1" class="form-label">
                Email address
              </label>
              <input
                type="email"
                class="form-control"
                id="exampleInputEmail1"
                aria-describedby="emailHelp"
                onChange={(e) => setEmail(e.target.value)}
                value={email}
              />
            </div>
            <div class="mb-3">
              <label for="exampleInputPassword1" class="form-label">
                Password
              </label>
              <input
                type="password"
                class="form-control"
                id="exampleInputPassword1"
                onChange={(e) => setPassword(e.target.value)}
                value={password}
              />
            </div>
            <button
              type="submit"
              class="btn btn-primary"
              onClick={submitDetails}
            >
              Create Account
            </button>
          </form>
        </div>
        <div className="error">{message}</div>
      </div>
    </div>
  );
};
export default CreateAccount;
