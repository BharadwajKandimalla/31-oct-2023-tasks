import React, { useState } from "react";
import { Link } from "react-router-dom/cjs/react-router-dom.min";
const Login = ({ setToken }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setRes] = useState("");
  const submitDetails = async (e) => {
    e.preventDefault();
    const token = await LoginUser({
      username: "kminchelle",
      password: "0lelplR",
      // username: email,
      // password,
    });
    setToken(token);
  };
  async function LoginUser(credentials) {
    return fetch("https://dummyjson.com/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(credentials),
    })
      .then((res) => res.json())
      .then((resp) => {
        setRes(
          resp?.message
            ? { key: "error", value: resp?.message }
            : "Logged in successfully"
        );
        setTimeout(() => {
          setRes("");
        }, 5000);
        setEmail("");
        setPassword("");
      });
  }

  return (
    <div data-testid="login">
      <div class="card my_login_card">
        <div>
          <strong> User Authentication </strong>

          <Link to="/dashboard">Go To Dashbaord</Link>
        </div>

        <div class="card-body">
          <form>
            <div class="mb-3">
              <label for="exampleInputEmail1" class="form-label">
                Email address
              </label>
              <input
                type="email"
                class="form-control"
                id="exampleInputEmail1"
                aria-describedby="emailHelp"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div class="mb-3">
              <label for="exampleInputPassword1" class="form-label">
                Password
              </label>
              <input
                type="password"
                class="form-control"
                value={password}
                id="exampleInputPassword1"
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            <button
              type="submit"
              class="btn btn-primary"
              onClick={submitDetails}
            >
              Login
            </button>
          </form>
        </div>
        <div>
          {message?.key ? (
            <span className="error">{message?.value}</span>
          ) : (
            <span className="success">{message}</span>
          )}
        </div>
      </div>
    </div>
  );
};
export default Login;
