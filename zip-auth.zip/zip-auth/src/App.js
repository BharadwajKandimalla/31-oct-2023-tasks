import "./App.css";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import { BrowserRouter, Route, Switch } from "react-router-dom";
import Dashboard from "./Dashboard/Dashboard.jsx";
import Login from "./login/Login";
import CreateAccount from "./create/CreateAccount";
import { useEffect, useState } from "react";
function App() {
  const [token, setToken] = useState("");
  useEffect(() => {
    localStorage.setItem('token',token)
  }, [token]);
  return (
    <div className="wrapper">
      <BrowserRouter>
        <Switch>
          <Route path="/createaccount">
            <CreateAccount />
          </Route>
          <Route path="/dashboard">
            <Dashboard />
          </Route>

          <Route path="/">
            <Login setToken={setToken} />
          </Route>
        </Switch>
      </BrowserRouter>
    </div>
  );
}
export default App;
